'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function SubmitPage() {
  const [activeTab, setActiveTab] = useState('submit');
  const [formData, setFormData] = useState({
    modName: '',
    description: '',
    category: '',
    version: '',
    minecraftVersion: '',
    modType: '',
    downloadLink: '',
    images: [],
    tags: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Mod submitted:', formData);
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=minecraft%20mod%20development%20workspace%20code%20editor%20multiple%20monitors%20gaming%20setup%20professional%20streamer%20background%20neon%20lighting%20cyberpunk%20atmosphere%20detailed&width=1920&height=1080&seq=submit-hero&orientation=landscape')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-950/80 via-gray-950/90 to-gray-950"></div>
        
        <div className="relative max-w-7xl mx-auto">
          {/* Site Owner Introduction */}
          <div className="text-center mb-16">
            <div className="mb-8">
              <img
                src="https://readdy.ai/api/search-image?query=professional%20gaming%20content%20creator%20avatar%20modern%20gaming%20setup%20headset%20microphone%20streaming%20background%20purple%20blue%20neon%20lighting%20portrait%20style&width=200&height=200&seq=owner-avatar&orientation=squarish"
                alt="Crazy Devil 888 - Site Owner"
                className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-green-500"
              />
              <h1 className="text-5xl font-bold mb-4">Welcome to ModCraft</h1>
              <p className="text-xl text-green-400 mb-2">Created by <strong>Crazy Devil 888</strong></p>
              <p className="text-gray-300 max-w-3xl mx-auto leading-relaxed">
                Hey gamers! I'm the owner and creator of ModCraft. As a passionate Minecraft content creator and modding enthusiast, 
                I built this platform to help our amazing community discover, share, and enjoy the best mods available.
              </p>
            </div>

            {/* YouTube Channel Showcase */}
            <div className="bg-gradient-to-r from-red-600/20 to-red-500/20 backdrop-blur-sm border border-red-500/30 rounded-2xl p-8 mb-12 max-w-4xl mx-auto">
              <div className="flex items-center justify-center space-x-4 mb-6">
                <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center">
                  <i className="ri-youtube-fill text-white text-2xl"></i>
                </div>
                <div className="text-left">
                  <h3 className="text-2xl font-bold text-white">Crazy Devil 888 Gaming</h3>
                  <p className="text-red-400">Official YouTube Channel</p>
                </div>
              </div>
              
              <p className="text-gray-300 mb-6 leading-relaxed">
                Follow my gaming journey! I create content about Minecraft mods, gameplay tutorials, 
                mod reviews, and gaming tips. Subscribe to stay updated with the latest mod showcases and gaming content.
              </p>
              
              <div className="flex flex-wrap justify-center gap-4">
                <a
                  href="https://youtube.com/@crazydevil888official"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-xl font-bold flex items-center space-x-2 transition-all duration-200 shadow-xl hover:shadow-2xl hover:scale-105 cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-youtube-fill text-xl"></i>
                  <span>Subscribe Now</span>
                </a>
                <button className="bg-gray-800 hover:bg-gray-700 border border-gray-600 text-white px-8 py-4 rounded-xl font-medium flex items-center space-x-2 transition-colors cursor-pointer whitespace-nowrap">
                  <i className="ri-notification-line"></i>
                  <span>Get Notified</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-400">500K+</div>
                  <div className="text-gray-300 text-sm">Subscribers</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-400">10M+</div>
                  <div className="text-gray-300 text-sm">Total Views</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-400">200+</div>
                  <div className="text-gray-300 text-sm">Mod Reviews</div>
                </div>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex justify-center mb-12">
            <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-2xl p-2">
              <nav className="flex space-x-2">
                {[
                  { key: 'submit', label: 'Submit Your Mod', icon: 'ri-upload-line' },
                  { key: 'guidelines', label: 'Guidelines', icon: 'ri-file-list-line' },
                  { key: 'featured', label: 'Get Featured', icon: 'ri-star-line' }
                ].map(tab => (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all duration-200 cursor-pointer whitespace-nowrap ${
                      activeTab === tab.key 
                        ? 'bg-green-600 text-white shadow-lg' 
                        : 'text-gray-300 hover:text-white hover:bg-gray-700'
                    }`}
                  >
                    <i className={tab.icon}></i>
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Tab Content */}
          {activeTab === 'submit' && (
            <div className="max-w-4xl mx-auto">
              <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-2xl p-8">
                <h2 className="text-3xl font-bold text-center mb-8">Submit Your Mod</h2>
                
                <form id="mod-submission" onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Mod Name *</label>
                      <input
                        type="text"
                        name="modName"
                        value={formData.modName}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        placeholder="Enter your mod name"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Category *</label>
                      <select
                        name="category"
                        value={formData.category}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-green-500 pr-8"
                      >
                        <option value="">Select category</option>
                        <option value="technology">Technology & Automation</option>
                        <option value="adventure">Adventure & Exploration</option>
                        <option value="magic">Magic & Mysticism</option>
                        <option value="building">Building & Decoration</option>
                        <option value="tools">Tools & Utilities</option>
                        <option value="combat">Combat & Weapons</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Mod Version *</label>
                      <input
                        type="text"
                        name="version"
                        value={formData.version}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        placeholder="1.0.0"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Minecraft Version *</label>
                      <select
                        name="minecraftVersion"
                        value={formData.minecraftVersion}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-green-500 pr-8"
                      >
                        <option value="">Select version</option>
                        <option value="1.20.4">1.20.4</option>
                        <option value="1.20.2">1.20.2</option>
                        <option value="1.19.4">1.19.4</option>
                        <option value="1.19.2">1.19.2</option>
                        <option value="1.18.2">1.18.2</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Description *</label>
                    <textarea
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      required
                      maxLength={500}
                      rows={5}
                      className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-green-500 resize-none"
                      placeholder="Describe your mod, its features, and what makes it special..."
                    />
                    <p className="text-gray-400 text-sm mt-1">{formData.description.length}/500 characters</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Download Link *</label>
                    <input
                      type="url"
                      name="downloadLink"
                      value={formData.downloadLink}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      placeholder="https://your-mod-download-link.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Tags</label>
                    <input
                      type="text"
                      name="tags"
                      value={formData.tags}
                      onChange={handleInputChange}
                      className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      placeholder="forge, automation, energy (comma separated)"
                    />
                  </div>

                  <div className="text-center pt-6">
                    <button
                      type="submit"
                      className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white px-12 py-4 rounded-xl font-bold text-lg transition-all duration-200 shadow-xl hover:shadow-2xl hover:scale-105 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-upload-line mr-2"></i>
                      Submit Mod for Review
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {activeTab === 'guidelines' && (
            <div className="max-w-4xl mx-auto">
              <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-2xl p-8">
                <h2 className="text-3xl font-bold text-center mb-8">Submission Guidelines</h2>
                
                <div className="prose prose-invert max-w-none">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                    <div className="bg-green-600/10 border border-green-500/30 rounded-xl p-6">
                      <h3 className="text-xl font-bold text-green-400 mb-4">✅ What We Accept</h3>
                      <ul className="space-y-2 text-gray-300">
                        <li>• Original Minecraft modifications</li>
                        <li>• Server plugins (Bukkit/Spigot/Paper)</li>
                        <li>• Resource packs and texture packs</li>
                        <li>• Quality modpacks</li>
                        <li>• Educational/tutorial content</li>
                      </ul>
                    </div>
                    
                    <div className="bg-red-600/10 border border-red-500/30 rounded-xl p-6">
                      <h3 className="text-xl font-bold text-red-400 mb-4">❌ What We Don't Accept</h3>
                      <ul className="space-y-2 text-gray-300">
                        <li>• Malicious or harmful content</li>
                        <li>• Copyrighted material</li>
                        <li>• Adult or inappropriate content</li>
                        <li>• Stolen or plagiarized work</li>
                        <li>• Low-quality submissions</li>
                      </ul>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-4">Submission Requirements</h3>
                      <div className="bg-gray-700/30 rounded-xl p-6">
                        <ol className="list-decimal list-inside space-y-3 text-gray-300">
                          <li><strong>Complete Information:</strong> Fill out all required fields accurately</li>
                          <li><strong>Clear Description:</strong> Explain what your mod does and its key features</li>
                          <li><strong>Valid Download Link:</strong> Provide a working download link</li>
                          <li><strong>Screenshots:</strong> Include high-quality screenshots or images</li>
                          <li><strong>Version Compatibility:</strong> Specify supported Minecraft versions</li>
                          <li><strong>Dependencies:</strong> List any required mods or libraries</li>
                        </ol>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-2xl font-bold text-white mb-4">Review Process</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="text-center bg-blue-600/10 border border-blue-500/30 rounded-xl p-4">
                          <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3">
                            <i className="ri-file-check-line text-white"></i>
                          </div>
                          <h4 className="font-bold text-blue-400">1. Submission</h4>
                          <p className="text-gray-300 text-sm mt-2">Your mod is submitted and queued for review</p>
                        </div>
                        <div className="text-center bg-yellow-600/10 border border-yellow-500/30 rounded-xl p-4">
                          <div className="w-12 h-12 bg-yellow-600 rounded-full flex items-center justify-center mx-auto mb-3">
                            <i className="ri-search-line text-white"></i>
                          </div>
                          <h4 className="font-bold text-yellow-400">2. Review</h4>
                          <p className="text-gray-300 text-sm mt-2">Our team reviews for quality and compliance</p>
                        </div>
                        <div className="text-center bg-green-600/10 border border-green-500/30 rounded-xl p-4">
                          <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-3">
                            <i className="ri-check-line text-white"></i>
                          </div>
                          <h4 className="font-bold text-green-400">3. Approval</h4>
                          <p className="text-gray-300 text-sm mt-2">Your mod goes live on the platform</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'featured' && (
            <div className="max-w-4xl mx-auto">
              <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-2xl p-8">
                <h2 className="text-3xl font-bold text-center mb-8">Get Featured on Our Channel</h2>
                
                <div className="text-center mb-8">
                  <div className="w-20 h-20 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="ri-star-fill text-white text-2xl"></i>
                  </div>
                  <p className="text-gray-300 text-lg leading-relaxed">
                    Have an amazing mod? Get it featured on <strong>Crazy Devil 888 Gaming</strong> YouTube channel! 
                    I regularly showcase the best community mods with gameplay reviews and tutorials.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                  <div className="bg-purple-600/10 border border-purple-500/30 rounded-xl p-6">
                    <h3 className="text-xl font-bold text-purple-400 mb-4">🎥 Featured Benefits</h3>
                    <ul className="space-y-3 text-gray-300">
                      <li className="flex items-center space-x-3">
                        <i className="ri-play-circle-line text-purple-400"></i>
                        <span>Gameplay showcase video</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <i className="ri-eye-line text-purple-400"></i>
                        <span>Exposure to 500K+ subscribers</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <i className="ri-share-line text-purple-400"></i>
                        <span>Cross-platform promotion</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <i className="ri-trophy-line text-purple-400"></i>
                        <span>Featured mod badge</span>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-blue-600/10 border border-blue-500/30 rounded-xl p-6">
                    <h3 className="text-xl font-bold text-blue-400 mb-4">📋 Requirements</h3>
                    <ul className="space-y-3 text-gray-300">
                      <li className="flex items-center space-x-3">
                        <i className="ri-check-line text-blue-400"></i>
                        <span>High-quality, unique mod</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <i className="ri-check-line text-blue-400"></i>
                        <span>Well-documented features</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <i className="ri-check-line text-blue-400"></i>
                        <span>Active development</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <i className="ri-check-line text-blue-400"></i>
                        <span>Community engagement</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-xl p-6 text-center">
                  <h3 className="text-2xl font-bold text-white mb-4">Ready to Get Featured?</h3>
                  <p className="text-gray-300 mb-6">
                    Submit your best mods and I'll personally review them for potential YouTube features. 
                    The most innovative and entertaining mods get priority!
                  </p>
                  <div className="flex flex-wrap justify-center gap-4">
                    <button 
                      onClick={() => setActiveTab('submit')}
                      className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-400 text-white px-8 py-4 rounded-xl font-bold transition-all duration-200 shadow-xl hover:shadow-2xl hover:scale-105 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-upload-line mr-2"></i>
                      Submit Your Mod
                    </button>
                    <a
                      href="https://youtube.com/@crazydevil888official"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-xl font-bold flex items-center space-x-2 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-youtube-fill"></i>
                      <span>Watch Previous Reviews</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}