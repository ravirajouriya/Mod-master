
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import EnhancedSearchBar from '@/components/EnhancedSearchBar';
import TrendingCarousel from '@/components/TrendingCarousel';
import CategoryCard from '@/components/CategoryCard';
import AnimatedModCard from '@/components/AnimatedModCard';
import Link from 'next/link';

export default function Home() {
  const categories = [
    {
      title: "Technology & Automation",
      icon: "ri-cpu-line",
      count: 3247,
      description: "Advanced machinery, automation systems, and digital storage"
    },
    {
      title: "Adventure & Exploration",
      icon: "ri-compass-3-line",
      count: 2892,
      description: "New dimensions, biomes, structures, and quest content"
    },
    {
      title: "Magic & Mysticism",
      icon: "ri-magic-line",
      count: 1658,
      description: "Spells, enchantments, and supernatural abilities"
    },
    {
      title: "Building & Decoration",
      icon: "ri-building-4-line",
      count: 2134,
      description: "Beautiful blocks, furniture, and architectural elements"
    },
    {
      title: "Tools & Utilities",
      icon: "ri-tools-line",
      count: 1834,
      description: "Quality of life improvements and helpful tools"
    },
    {
      title: "Combat & Weapons",
      icon: "ri-sword-line",
      count: 1423,
      description: "New weapons, armor, and combat mechanics"
    }
  ];

  const featuredMods = [
    {
      id: "1",
      title: "Applied Energistics 2",
      author: "AlgorithmX2",
      description: "A revolutionary mod that provides a comprehensive digital storage solution and automated crafting system for advanced players.",
      downloads: 25420000,
      likes: 156780,
      views: 2847392,
      rating: 4.8,
      version: "12.9.7",
      category: "Technology",
      tags: ["Forge", "Storage", "Automation", "Energy"],
      lastUpdated: "2 days ago"
    },
    {
      id: "2",
      title: "Create",
      author: "simibubi",
      description: "Build incredible contraptions with rotating, moving, and animated machinery. Perfect for engineers and creative builders.",
      downloads: 31250000,
      likes: 234567,
      views: 4582947,
      rating: 4.9,
      version: "0.5.1f",
      category: "Technology",
      tags: ["Forge", "Fabric", "Mechanical", "Building"],
      lastUpdated: "1 week ago"
    },
    {
      id: "3",
      title: "JEI (Just Enough Items)",
      author: "mezz",
      description: "The essential recipe viewing mod that shows crafting recipes, uses, and detailed item information in a clean interface.",
      downloads: 42150000,
      likes: 189234,
      views: 5247382,
      rating: 4.9,
      version: "15.2.0.27",
      category: "Utility",
      tags: ["Forge", "Fabric", "Quilt", "Essential"],
      lastUpdated: "3 days ago"
    },
    {
      id: "4",
      title: "Tinkers' Construct",
      author: "mDiyo",
      description: "Customize and craft unique tools and weapons by combining different materials, modifiers, and special abilities.",
      downloads: 28890000,
      likes: 198765,
      views: 3847291,
      rating: 4.7,
      version: "3.7.1.185",
      category: "Tools",
      tags: ["Forge", "Tools", "Customization", "Crafting"],
      lastUpdated: "5 days ago"
    },
    {
      id: "5",
      title: "Biomes O' Plenty",
      author: "Forstride",
      description: "Discover over 80 new biomes, blocks, and environmental features that make exploration exciting and rewarding.",
      downloads: 23740000,
      likes: 142356,
      views: 2957384,
      rating: 4.6,
      version: "18.0.0.592",
      category: "Adventure",
      tags: ["Forge", "Fabric", "Biomes", "Exploration"],
      lastUpdated: "1 week ago"
    },
    {
      id: "6",
      title: "Thermal Expansion",
      author: "TeamCoFH",
      description: "Advanced machines, energy systems, and processing automation for industrial-scale operations and resource management.",
      downloads: 19740000,
      likes: 134782,
      views: 2485739,
      rating: 4.7,
      version: "10.4.2.18",
      category: "Technology",
      tags: ["Forge", "Energy", "Machines", "Industrial"],
      lastUpdated: "4 days ago"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Header />
      
      {/* Enhanced Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div 
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=minecraft%20futuristic%20digital%20landscape%20with%20glowing%20green%20and%20blue%20tech%20elements%20circuit%20patterns%20holographic%20displays%20dark%20atmosphere%20cyberpunk%20style%20cinematic%20lighting%208k%20detailed&width=1920&height=1080&seq=hero-enhanced&orientation=landscape')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-950/50 via-gray-950/70 to-gray-950"></div>
        
        <div className="relative max-w-7xl mx-auto text-center">
          <div className="mb-8 inline-flex items-center bg-gradient-to-r from-green-900/20 to-blue-900/20 backdrop-blur-sm border border-green-500/30 rounded-full px-6 py-2">
            <i className="ri-fire-line text-orange-400 mr-2"></i>
            <span className="text-green-400 font-medium">Over 50,000 mods available</span>
          </div>

          <h1 className="text-6xl md:text-8xl font-black mb-8 leading-tight">
            <span className="block text-white">Minecraft Mods</span>
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-green-400 via-blue-500 to-purple-500 animate-gradient-x">
              Reimagined
            </span>
          </h1>

          <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto leading-relaxed">
            Discover, download, and share the most innovative Minecraft modifications. 
            Join millions of players enhancing their gaming experience.
          </p>
          
          <div className="mb-16">
            <EnhancedSearchBar />
          </div>
          
          <div className="flex flex-wrap justify-center gap-6 text-sm">
            <div className="bg-gray-800/80 backdrop-blur-sm border border-gray-700 px-6 py-3 rounded-2xl">
              <span className="text-green-400 font-bold text-lg">50K+</span>
              <span className="text-gray-300 ml-2">Active Mods</span>
            </div>
            <div className="bg-gray-800/80 backdrop-blur-sm border border-gray-700 px-6 py-3 rounded-2xl">
              <span className="text-blue-400 font-bold text-lg">2.5M+</span>
              <span className="text-gray-300 ml-2">Daily Downloads</span>
            </div>
            <div className="bg-gray-800/80 backdrop-blur-sm border border-gray-700 px-6 py-3 rounded-2xl">
              <span className="text-purple-400 font-bold text-lg">150K+</span>
              <span className="text-gray-300 ml-2">Community Members</span>
            </div>
          </div>
        </div>
      </section>

      {/* Trending Carousel */}
      <section className="py-20 px-4">
        <TrendingCarousel />
      </section>

      {/* Enhanced Categories Section */}
      <section className="py-20 px-4 bg-gray-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-300">
              Browse Categories
            </h2>
            <p className="text-gray-400 text-xl max-w-3xl mx-auto">
              Find exactly what you're looking for with our comprehensive mod categories
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categories.map((category, index) => (
              <div key={index} className="transform transition-all duration-500 hover:scale-105">
                <CategoryCard
                  title={category.title}
                  icon={category.icon}
                  count={category.count}
                  description={category.description}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Mods Section with Animated Cards */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-16">
            <div>
              <h2 className="text-5xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-300">
                Featured Mods
              </h2>
              <p className="text-gray-400 text-xl">
                Hand-picked selections from our community favorites
              </p>
            </div>
            <Link href="/mods" className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white px-8 py-4 rounded-xl font-semibold whitespace-nowrap cursor-pointer transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-105">
              <i className="ri-grid-line mr-2"></i>
              View All Mods
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredMods.map((mod, index) => (
              <div key={mod.id} style={{ animationDelay: `${index * 0.1}s` }} className="animate-fade-in-up">
                <AnimatedModCard
                  id={mod.id}
                  title={mod.title}
                  author={mod.author}
                  description={mod.description}
                  downloads={mod.downloads}
                  likes={mod.likes}
                  views={mod.views}
                  rating={mod.rating}
                  version={mod.version}
                  category={mod.category}
                  tags={mod.tags}
                  lastUpdated={mod.lastUpdated}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="relative bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 rounded-3xl p-1 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 opacity-75"></div>
            <div 
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage: `url('https://readdy.ai/api/search-image?query=minecraft%20creative%20building%20workshop%20with%20code%20editor%20screens%20mod%20development%20environment%20colorful%20blocks%20programming%20setup%20professional%20studio%20lighting%20detailed%204k&width=1200&height=600&seq=cta-bg&orientation=landscape')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
            />
            <div className="relative bg-gray-950 m-1 rounded-3xl p-16 text-center">
              <h2 className="text-5xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-blue-400">
                Ready to Share Your Creation?
              </h2>
              <p className="text-xl text-gray-300 mb-10 max-w-3xl mx-auto leading-relaxed">
                Join thousands of talented developers and share your amazing Minecraft modifications 
                with our thriving community of over 150,000 active players.
              </p>
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <Link href="/submit" className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white px-10 py-5 rounded-xl font-bold text-lg whitespace-nowrap cursor-pointer transition-all duration-200 shadow-xl hover:shadow-2xl hover:scale-105">
                  <i className="ri-upload-line mr-3"></i>
                  Upload Your Mod
                </Link>
                <Link href="/about" className="bg-transparent border-2 border-gray-600 hover:border-white text-gray-300 hover:text-white hover:bg-white/5 px-10 py-5 rounded-xl font-bold text-lg whitespace-nowrap cursor-pointer transition-all duration-200">
                  <i className="ri-information-line mr-3"></i>
                  Learn More
                </Link>
              </div>
              <div className="mt-10 flex justify-center space-x-8 text-sm text-gray-400">
                <div className="flex items-center space-x-2">
                  <i className="ri-shield-check-line text-green-400"></i>
                  <span>Secure & Trusted</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="ri-rocket-line text-blue-400"></i>
                  <span>Fast Review Process</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="ri-community-line text-purple-400"></i>
                  <span>Active Community</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />

      <style jsx>{`
        @keyframes gradient-x {
          0%, 100% {
            background-size: 200% 200%;
            background-position: left center;
          }
          50% {
            background-size: 200% 200%;
            background-position: right center;
          }
        }
        .animate-gradient-x {
          animation: gradient-x 3s ease infinite;
        }
        .animate-fade-in-up {
          animation: fadeInUp 0.6s ease-out forwards;
        }
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
