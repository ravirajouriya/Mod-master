
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { getModById, type Mod } from '@/lib/modDatabase';

interface ModDetailProps {
  modId: string;
}

export default function ModDetail({ modId }: ModDetailProps) {
  const [activeTab, setActiveTab] = useState('description');
  const [selectedVersion, setSelectedVersion] = useState('');
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [isDownloading, setIsDownloading] = useState(false);
  const [modData, setModData] = useState<Mod | null>(null);

  useEffect(() => {
    const mod = getModById(modId);
    if (mod) {
      setModData(mod);
      setSelectedVersion(mod.versions[0]?.version || '');
    }
  }, [modId]);

  if (!modData) {
    return (
      <div className="min-h-screen bg-gray-950 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <h2 className="text-2xl font-bold mb-2">Loading Mod Details...</h2>
          <p className="text-gray-400">Please wait while we fetch the mod information</p>
        </div>
      </div>
    );
  }

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const handleDownload = () => {
    setShowDownloadModal(true);
  };

  const startDownload = () => {
    setIsDownloading(true);
    setDownloadProgress(0);
    
    const selectedVersionData = modData.versions.find(v => v.version === selectedVersion) || modData.versions[0];
    
    // Simulate download progress
    const interval = setInterval(() => {
      setDownloadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsDownloading(false);
          setShowDownloadModal(false);
          
          // Create download link
          const link = document.createElement('a');
          link.href = selectedVersionData.downloadUrl;
          link.download = `${modData.title.replace(/\s+/g, '-').toLowerCase()}-${selectedVersionData.version}.jar`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          
          return 100;
        }
        return prev + Math.random() * 20;
      });
    }, 200);
  };

  const shareUrl = () => {
    navigator.clipboard.writeText(window.location.href);
    // Show success message
    const originalText = 'Share';
    const button = document.querySelector('[data-share-button]') as HTMLElement;
    if (button) {
      button.innerHTML = '<i class="ri-check-line mr-2"></i>Copied!';
      setTimeout(() => {
        button.innerHTML = '<i class="ri-share-line mr-2"></i>Share';
      }, 2000);
    }
  };

  const currentVersionData = modData.versions.find(v => v.version === selectedVersion) || modData.versions[0];

  // Generate sample images based on mod category and type
  const generateModImages = () => {
    const baseQuery = `minecraft ${modData.type} ${modData.category} screenshot`;
    return [
      `${baseQuery} main interface detailed colorful game environment`,
      `${baseQuery} crafting recipe gui system organized layout`,
      `${baseQuery} gameplay features demonstration colorful blocks`,
      `${baseQuery} advanced features showcase detailed interface`
    ];
  };

  const modImages = generateModImages();

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Header />
      
      {/* Hero Banner */}
      <section className="relative h-96 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=$%7BmodImages%5B0%5D%7D&width=1920&height=600&seq=${modId}-hero&orientation=landscape')`
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/80 to-gray-950/20"></div>
        
        <div className="absolute inset-0 flex items-end">
          <div className="max-w-7xl mx-auto w-full px-6 pb-12">
            <div className="flex flex-col md:flex-row items-start md:items-end space-y-6 md:space-y-0 md:space-x-8">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-4">
                  <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    {modData.category}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    modData.type === 'mod' ? 'bg-green-600 text-white' : 
                    modData.type === 'plugin' ? 'bg-orange-600 text-white' : 
                    'bg-purple-600 text-white'
                  }`}>
                    {modData.type.charAt(0).toUpperCase() + modData.type.slice(1)}
                  </span>
                  <div className="flex items-center space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <i
                        key={star}
                        className={`ri-star-${star <= modData.rating ? 'fill' : 'line'} text-yellow-400`}
                      />
                    ))}
                    <span className="text-white font-medium ml-2">{modData.rating}</span>
                  </div>
                </div>
                
                <h1 className="text-5xl font-bold mb-4">{modData.title}</h1>
                <p className="text-xl text-gray-300 mb-6 max-w-3xl">{modData.description}</p>
                
                <div className="flex items-center space-x-6 text-sm">
                  <div className="flex items-center space-x-2">
                    <i className="ri-download-line text-green-400"></i>
                    <span>{formatNumber(modData.downloads)} downloads</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <i className="ri-heart-line text-red-400"></i>
                    <span>{formatNumber(modData.likes)} likes</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <i className="ri-eye-line text-blue-400"></i>
                    <span>{formatNumber(modData.views)} views</span>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col space-y-3">
                <button
                  onClick={handleDownload}
                  className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white px-8 py-4 rounded-xl font-bold text-lg whitespace-nowrap cursor-pointer transition-all duration-200 shadow-xl hover:shadow-2xl hover:scale-105"
                >
                  <i className="ri-download-line mr-2"></i>
                  Download v{modData.versions[0]?.version}
                </button>
                
                <div className="flex space-x-2">
                  <button className="bg-gray-800 hover:bg-gray-700 border border-gray-600 text-white p-3 rounded-lg transition-colors cursor-pointer">
                    <i className="ri-heart-line"></i>
                  </button>
                  <button 
                    onClick={shareUrl}
                    data-share-button
                    className="bg-gray-800 hover:bg-gray-700 border border-gray-600 text-white p-3 rounded-lg transition-colors cursor-pointer flex items-center"
                  >
                    <i className="ri-share-line"></i>
                  </button>
                  <button className="bg-gray-800 hover:bg-gray-700 border border-gray-600 text-white p-3 rounded-lg transition-colors cursor-pointer">
                    <i className="ri-bookmark-line"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Tab Navigation */}
            <div className="border-b border-gray-700 mb-8">
              <nav className="flex space-x-8">
                {[
                  { key: 'description', label: 'Description', icon: 'ri-information-line' },
                  { key: 'gallery', label: 'Gallery', icon: 'ri-image-line' },
                  { key: 'versions', label: 'Versions', icon: 'ri-history-line' }
                ].map(tab => (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className={`flex items-center space-x-2 pb-4 px-2 border-b-2 transition-colors cursor-pointer ${
                      activeTab === tab.key 
                        ? 'border-green-500 text-green-400' 
                        : 'border-transparent text-gray-400 hover:text-white'
                    }`}
                  >
                    <i className={tab.icon}></i>
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>

            {/* Tab Content */}
            {activeTab === 'description' && (
              <div className="prose prose-invert max-w-none">
                <p className="text-lg text-gray-300 leading-relaxed mb-8">
                  {modData.longDescription}
                </p>
                
                <h3 className="text-2xl font-bold mb-4">Key Features</h3>
                <ul className="list-disc list-inside space-y-2 text-gray-300 mb-8">
                  {modData.type === 'mod' ? [
                    "Advanced functionality and gameplay enhancements",
                    "Seamless integration with existing game mechanics", 
                    "Extensive configuration options and customization",
                    "Performance optimized for smooth gameplay",
                    "Regular updates and community support",
                    "Compatible with popular mod loaders"
                  ] : [
                    "Server-side plugin with administrative features",
                    "Easy installation and configuration",
                    "Comprehensive command system",
                    "Permission-based access control",
                    "Performance optimized for multiplayer servers", 
                    "Regular security updates and bug fixes"
                  ].map((feature, index) => (
                    <li key={index}>{feature}</li>
                  ))}
                </ul>

                <h3 className="text-2xl font-bold mb-4">Installation Guide</h3>
                <ol className="list-decimal list-inside space-y-2 text-gray-300">
                  {modData.type === 'mod' ? [
                    `Make sure you have ${modData.modLoader.join(' or ')} installed`,
                    "Download the mod file for your Minecraft version", 
                    "Place the .jar file in your mods folder",
                    "Launch Minecraft with the appropriate mod loader profile",
                    "Enjoy your enhanced gameplay experience!"
                  ] : [
                    "Make sure you have a Bukkit/Spigot/Paper server",
                    "Download the plugin file for your server version",
                    "Place the .jar file in your plugins folder", 
                    "Restart your server to load the plugin",
                    "Configure the plugin settings as needed"
                  ].map((step, index) => (
                    <li key={index}>{step}</li>
                  ))}
                </ol>
              </div>
            )}

            {activeTab === 'gallery' && (
              <div>
                {/* Main Image */}
                <div className="relative mb-6">
                  <img
                    src={`https://readdy.ai/api/search-image?query=$%7BmodImages%5BcurrentImageIndex%5D%7D&width=800&height=500&seq=${modId}-gallery-${currentImageIndex}&orientation=landscape`}
                    alt={`${modData.title} screenshot ${currentImageIndex + 1}`}
                    className="w-full h-96 object-cover rounded-xl"
                  />
                  
                  {/* Navigation Arrows */}
                  <button
                    onClick={() => setCurrentImageIndex((prev) => (prev - 1 + modImages.length) % modImages.length)}
                    className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-gray-900/80 hover:bg-gray-900 text-white w-12 h-12 rounded-full flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <i className="ri-arrow-left-line"></i>
                  </button>
                  <button
                    onClick={() => setCurrentImageIndex((prev) => (prev + 1) % modImages.length)}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-gray-900/80 hover:bg-gray-900 text-white w-12 h-12 rounded-full flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <i className="ri-arrow-right-line"></i>
                  </button>
                </div>

                {/* Thumbnail Grid */}
                <div className="grid grid-cols-4 gap-4">
                  {modImages.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`relative h-24 rounded-lg overflow-hidden cursor-pointer transition-all duration-200 ${
                        index === currentImageIndex ? 'ring-2 ring-green-500' : 'hover:scale-105'
                      }`}
                    >
                      <img
                        src={`https://readdy.ai/api/search-image?query=$%7BmodImages%5Bindex%5D%7D&width=200&height=150&seq=${modId}-thumb-${index}&orientation=landscape`}
                        alt={`Screenshot ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'versions' && (
              <div className="space-y-6">
                {modData.versions.map((version, index) => (
                  <div key={index} className="border border-gray-700 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <h3 className="text-xl font-bold text-green-400">Version {version.version}</h3>
                        {version.isLatest && (
                          <span className="bg-green-600 text-white px-2 py-1 rounded-full text-xs font-medium">
                            Latest
                          </span>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="text-gray-400 text-sm">Minecraft {version.mcVersion}</p>
                        <p className="text-gray-400 text-sm">{version.releaseDate}</p>
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <div className="flex items-center space-x-4 text-sm text-gray-300">
                        <span>Size: {version.fileSize}</span>
                        <span>•</span>
                        <span>MC {version.mcVersion}</span>
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <h4 className="text-sm font-semibold text-gray-300 mb-2">Changes:</h4>
                      <ul className="list-disc list-inside space-y-1 text-gray-400 text-sm">
                        {version.changelog.map((change, changeIndex) => (
                          <li key={changeIndex}>{change}</li>
                        ))}
                      </ul>
                    </div>
                    
                    <button 
                      onClick={() => {
                        setSelectedVersion(version.version);
                        handleDownload();
                      }}
                      className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-download-line mr-2"></i>
                      Download v{version.version}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Author Info */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h3 className="text-lg font-bold mb-4">Author</h3>
              <div className="flex items-center space-x-4">
                <img
                  src={`https://readdy.ai/api/search-image?query=minecraft%20mod%20developer%20avatar%20professional%20programmer%20digital%20art%20clean%20background%20portrait%20style&width=200&height=200&seq=author-${modData.author}&orientation=squarish`}
                  alt={modData.author}
                  className="w-12 h-12 rounded-full"
                />
                <div>
                  <Link href={`/mods?author=${encodeURIComponent(modData.author)}`} className="font-semibold text-green-400 hover:text-green-300 cursor-pointer">
                    {modData.author}
                  </Link>
                  <p className="text-gray-400 text-sm">{modData.type === 'mod' ? 'Mod Developer' : 'Plugin Developer'}</p>
                </div>
              </div>
              <button className="w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap">
                <i className="ri-user-add-line mr-2"></i>
                Follow
              </button>
            </div>

            {/* Mod Info */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h3 className="text-lg font-bold mb-4">Details</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Current Version</span>
                  <span className="text-green-400 font-medium">v{modData.versions[0]?.version}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">File Size</span>
                  <span className="text-white">{modData.versions[0]?.fileSize}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Last Updated</span>
                  <span className="text-white">{modData.lastUpdated}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Downloads</span>
                  <span className="text-white">{formatNumber(modData.downloads)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">License</span>
                  <span className="text-white">{modData.license}</span>
                </div>
              </div>
            </div>

            {/* Supported Versions */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h3 className="text-lg font-bold mb-4">Minecraft Versions</h3>
              <div className="flex flex-wrap gap-2">
                {Array.from(new Set(modData.versions.map(v => v.mcVersion))).map(version => (
                  <span key={version} className="bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-sm">
                    {version}
                  </span>
                ))}
              </div>
            </div>

            {/* Mod Loaders */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h3 className="text-lg font-bold mb-4">Mod Loaders</h3>
              <div className="flex flex-wrap gap-2">
                {modData.modLoader.map(loader => (
                  <span key={loader} className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">
                    {loader}
                  </span>
                ))}
              </div>
            </div>

            {/* Tags */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h3 className="text-lg font-bold mb-4">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {modData.tags.map(tag => (
                  <span key={tag} className="bg-green-600 text-white px-3 py-1 rounded-full text-sm">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Dependencies */}
            {modData.dependencies && modData.dependencies.length > 0 && (
              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <h3 className="text-lg font-bold mb-4">Dependencies</h3>
                <div className="space-y-2">
                  {modData.dependencies.map((dep, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <i className="ri-link text-green-400"></i>
                      <span className="text-gray-300 text-sm">{dep}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Download Modal */}
      {showDownloadModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-2xl p-8 max-w-md w-full border border-gray-700">
            <h3 className="text-2xl font-bold mb-6 text-center">Download {modData.title}</h3>
            
            {!isDownloading ? (
              <>
                <div className="mb-6">
                  <label className="block text-sm font-medium mb-2">Select Version</label>
                  <select 
                    value={selectedVersion}
                    onChange={(e) => setSelectedVersion(e.target.value)}
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white pr-8"
                  >
                    {modData.versions.map(version => (
                      <option key={version.version} value={version.version}>
                        v{version.version} - MC {version.mcVersion} {version.isLatest ? '(Latest)' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="bg-gray-700 rounded-lg p-4 mb-6 text-sm">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-400">File Name</span>
                    <span className="text-white">{modData.title.replace(/\s+/g, '-').toLowerCase()}-{currentVersionData.version}.jar</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-400">File Size</span>
                    <span className="text-white">{currentVersionData.fileSize}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-400">Minecraft Version</span>
                    <span className="text-white">{currentVersionData.mcVersion}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Release Date</span>
                    <span className="text-white">{currentVersionData.releaseDate}</span>
                  </div>
                </div>

                <div className="flex space-x-4">
                  <button
                    onClick={() => setShowDownloadModal(false)}
                    className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={startDownload}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-download-line mr-2"></i>
                    Download
                  </button>
                </div>
              </>
            ) : (
              <div className="text-center">
                <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-download-line text-2xl text-white"></i>
                </div>
                <h4 className="text-lg font-medium mb-2">Preparing Download...</h4>
                <div className="bg-gray-700 rounded-full h-3 mb-4">
                  <div 
                    className="bg-green-600 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${downloadProgress}%` }}
                  ></div>
                </div>
                <p className="text-gray-400 text-sm">{Math.round(downloadProgress)}% complete</p>
              </div>
            )}
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}