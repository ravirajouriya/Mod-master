
import ModDetail from './ModDetail';
import { modDatabase } from '@/lib/modDatabase';

export async function generateStaticParams() {
  // Generate params for all mods in the database
  return modDatabase.map(mod => ({
    id: mod.id
  }));
}

export default function ModPage({ params }: { params: { id: string } }) {
  return <ModDetail modId={params.id} />;
}