
'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import EnhancedSearchBar from '@/components/EnhancedSearchBar';
import FilterSidebar from '@/components/FilterSidebar';
import AnimatedModCard from '@/components/AnimatedModCard';
import { searchMods, modDatabase } from '@/lib/modDatabase';

function ModsContent() {
  const searchParams = useSearchParams();
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [sortBy, setSortBy] = useState('downloads');
  const [viewMode, setViewMode] = useState('grid');
  const [displayMods, setDisplayMods] = useState(modDatabase);
  const [currentQuery, setCurrentQuery] = useState('');

  useEffect(() => {
    const searchQuery = searchParams.get('search') || '';
    const authorFilter = searchParams.get('author') || '';
    const categoryFilter = searchParams.get('category') || '';
    
    let filteredMods = modDatabase;
    
    if (searchQuery) {
      filteredMods = searchMods(searchQuery);
      setCurrentQuery(searchQuery);
    }
    
    if (authorFilter) {
      filteredMods = filteredMods.filter(mod => 
        mod.author.toLowerCase() === authorFilter.toLowerCase()
      );
      setCurrentQuery(`Author: ${authorFilter}`);
    }
    
    if (categoryFilter) {
      filteredMods = filteredMods.filter(mod => 
        mod.category.toLowerCase() === categoryFilter.toLowerCase()
      );
      setCurrentQuery(`Category: ${categoryFilter}`);
    }

    // Sort mods
    filteredMods.sort((a, b) => {
      switch (sortBy) {
        case 'downloads': return b.downloads - a.downloads;
        case 'rating': return b.rating - a.rating;
        case 'updated': return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
        case 'created': return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
        case 'trending': return (b.likes + b.views) - (a.likes + a.views);
        case 'name': return a.title.localeCompare(b.title);
        default: return 0;
      }
    });

    setDisplayMods(filteredMods);
  }, [searchParams, sortBy]);

  const sortOptions = [
    { value: 'downloads', label: 'Most Downloaded', icon: 'ri-download-line' },
    { value: 'rating', label: 'Highest Rated', icon: 'ri-star-line' },
    { value: 'updated', label: 'Recently Updated', icon: 'ri-time-line' },
    { value: 'created', label: 'Newest', icon: 'ri-add-line' },
    { value: 'trending', label: 'Trending', icon: 'ri-fire-line' },
    { value: 'name', label: 'Alphabetical', icon: 'ri-sort-alphabet-asc' }
  ];

  const handleSearch = (query: string) => {
    setCurrentQuery(query);
    const filtered = searchMods(query);
    setDisplayMods(filtered);
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col">
      <Header />
      
      {/* Page Header */}
      <section className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 py-16 px-4 border-b border-gray-700">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-300">
              {currentQuery ? `Search Results: "${currentQuery}"` : 'Discover Amazing Mods'}
            </h1>
            <p className="text-gray-400 text-xl max-w-3xl mx-auto">
              {currentQuery 
                ? `Found ${displayMods.length} mods matching your search`
                : 'Browse through thousands of community-created modifications, sorted and filtered to find exactly what you\'re looking for'
              }
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto mb-8">
            <EnhancedSearchBar onSearch={handleSearch} />
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <span className="bg-gray-800 border border-gray-700 px-4 py-2 rounded-full">
              <span className="text-green-400 font-semibold">{displayMods.length}</span> {currentQuery ? 'Results' : 'Total Mods'}
            </span>
            <span className="bg-gray-800 border border-gray-700 px-4 py-2 rounded-full">
              <span className="text-blue-400 font-semibold">2,349</span> Updated This Week
            </span>
            <span className="bg-gray-800 border border-gray-700 px-4 py-2 rounded-full">
              <span className="text-purple-400 font-semibold">456</span> New This Month
            </span>
          </div>
        </div>
      </section>

      <div className="flex-1 flex">
        {/* Filter Sidebar */}
        <FilterSidebar 
          isOpen={isFilterOpen} 
          onClose={() => setIsFilterOpen(false)}
        />

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {/* Controls Bar */}
          <div className="bg-gray-900 border-b border-gray-700 px-6 py-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setIsFilterOpen(true)}
                  className="lg:hidden bg-gray-800 hover:bg-gray-700 border border-gray-600 px-4 py-2 rounded-lg flex items-center space-x-2 cursor-pointer transition-colors"
                >
                  <i className="ri-filter-line"></i>
                  <span>Filters</span>
                </button>
                
                <span className="text-gray-400 text-sm">
                  Showing <span className="text-white font-medium">1-{Math.min(displayMods.length, 12)}</span> of <span className="text-white font-medium">{displayMods.length}</span> mods
                </span>
              </div>

              <div className="flex items-center space-x-4">
                {/* Sort Dropdown */}
                <div className="relative">
                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value)}
                    className="bg-gray-800 border border-gray-600 text-white px-4 py-2 pr-8 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 cursor-pointer"
                  >
                    {sortOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* View Mode Toggle */}
                <div className="flex bg-gray-800 border border-gray-600 rounded-lg overflow-hidden">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`px-3 py-2 cursor-pointer transition-colors ${
                      viewMode === 'grid' ? 'bg-green-600 text-white' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    <i className="ri-grid-line"></i>
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`px-3 py-2 cursor-pointer transition-colors ${
                      viewMode === 'list' ? 'bg-green-600 text-white' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    <i className="ri-list-unordered"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Mods Grid */}
          <div className="p-6">
            {displayMods.length === 0 ? (
              <div className="text-center py-20">
                <div className="w-24 h-24 mx-auto mb-6 bg-gray-800 rounded-full flex items-center justify-center">
                  <i className="ri-search-line text-4xl text-gray-500"></i>
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">No Mods Found</h3>
                <p className="text-gray-400 mb-8 max-w-md mx-auto">
                  We couldn't find any mods matching "{currentQuery}". Try adjusting your search terms or browse our categories.
                </p>
                <button 
                  onClick={() => {
                    setCurrentQuery('');
                    setDisplayMods(modDatabase);
                    window.history.pushState({}, '', '/mods');
                  }}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap"
                >
                  View All Mods
                </button>
              </div>
            ) : (
              <div className={`grid gap-6 ${
                viewMode === 'grid' 
                  ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3' 
                  : 'grid-cols-1 max-w-4xl mx-auto'
              }`}>
                {displayMods.slice(0, 12).map((mod, index) => (
                  <div key={mod.id} style={{ animationDelay: `${index * 0.05}s` }} className="animate-fade-in-up">
                    <AnimatedModCard
                      id={mod.id}
                      title={mod.title}
                      author={mod.author}
                      description={mod.description}
                      downloads={mod.downloads}
                      likes={mod.likes}
                      views={mod.views}
                      rating={mod.rating}
                      version={mod.versions[0]?.version || '1.0.0'}
                      category={mod.category}
                      tags={mod.tags}
                      lastUpdated={mod.lastUpdated}
                    />
                  </div>
                ))}
              </div>
            )}

            {/* Load More Button */}
            {displayMods.length > 12 && (
              <div className="text-center mt-12">
                <button className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white px-8 py-4 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-105 cursor-pointer whitespace-nowrap">
                  <i className="ri-refresh-line mr-2"></i>
                  Load More Mods ({displayMods.length - 12} remaining)
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />

      <style jsx>{`
        .animate-fade-in-up {
          animation: fadeInUp 0.4s ease-out forwards;
          opacity: 0;
        }
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}

export default function ModsPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gray-950 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <h2 className="text-2xl font-bold mb-2">Loading Mods...</h2>
          <p className="text-gray-400">Please wait while we fetch the latest mods</p>
        </div>
      </div>
    }>
      <ModsContent />
    </Suspense>
  );
}
