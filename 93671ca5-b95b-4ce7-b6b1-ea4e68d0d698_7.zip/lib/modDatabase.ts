'use client';

export interface ModVersion {
  version: string;
  mcVersion: string;
  downloadUrl: string;
  fileSize: string;
  releaseDate: string;
  changelog: string[];
  isLatest?: boolean;
}

export interface Mod {
  id: string;
  title: string;
  author: string;
  description: string;
  longDescription: string;
  downloads: number;
  likes: number;
  views: number;
  rating: number;
  category: string;
  type: 'mod' | 'plugin' | 'modpack' | 'resourcepack' | 'shader';
  tags: string[];
  lastUpdated: string;
  versions: ModVersion[];
  dependencies?: string[];
  featured?: boolean;
  trending?: boolean;
  license: string;
  environment: 'client' | 'server' | 'both';
  modLoader: string[];
}

export const modDatabase: Mod[] = [
  // Technology Mods
  {
    id: "applied-energistics-2",
    title: "Applied Energistics 2",
    author: "AlgorithmX2",
    description: "A comprehensive digital storage and automation system that revolutionizes resource management with advanced networking capabilities and automated crafting solutions.",
    longDescription: "Applied Energistics 2 is a revolutionary mod that completely transforms how you store, manage, and automate resources in Minecraft. With its advanced digital storage network, you can store thousands of items in a compact space while maintaining instant access through sophisticated search and sorting systems.",
    downloads: 25420000,
    likes: 156780,
    views: 2847392,
    rating: 4.8,
    category: "Technology",
    type: "mod",
    tags: ["Forge", "Storage", "Automation", "Energy", "Technology", "Industrial"],
    lastUpdated: "2 days ago",
    license: "LGPLv3",
    environment: "both",
    modLoader: ["Forge"],
    featured: true,
    trending: true,
    versions: [
      {
        version: "12.9.7",
        mcVersion: "1.20.4",
        downloadUrl: "/downloads/ae2-12.9.7-1.20.4.jar",
        fileSize: "8.4 MB",
        releaseDate: "2024-01-15",
        changelog: ["Fixed crash when opening ME Terminal", "Improved network performance", "Added compatibility with latest Forge"],
        isLatest: true
      },
      {
        version: "12.9.6",
        mcVersion: "1.20.2",
        downloadUrl: "/downloads/ae2-12.9.6-1.20.2.jar",
        fileSize: "8.2 MB",
        releaseDate: "2024-01-08",
        changelog: ["New crafting CPU multiblock", "Enhanced pattern terminal", "Fixed memory leak"]
      }
    ]
  },
  {
    id: "create",
    title: "Create",
    author: "simibubi",
    description: "Build incredible mechanical contraptions with rotating, moving, and animated machinery. Features advanced engineering mechanics for creative builders and redstone enthusiasts.",
    longDescription: "Create adds a variety of tools and blocks for Building, Decoration and Aesthetic Automation. The added elements of tech are designed to leave as many design choices to the player as possible.",
    downloads: 31250000,
    likes: 234567,
    views: 4582947,
    rating: 4.9,
    category: "Technology",
    type: "mod",
    tags: ["Forge", "Fabric", "Mechanical", "Building", "Automation"],
    lastUpdated: "1 week ago",
    license: "MIT",
    environment: "both",
    modLoader: ["Forge", "Fabric"],
    featured: true,
    trending: true,
    versions: [
      {
        version: "0.5.1f",
        mcVersion: "1.20.1",
        downloadUrl: "/downloads/create-0.5.1f-forge.jar",
        fileSize: "12.7 MB",
        releaseDate: "2024-01-10",
        changelog: ["Fixed contraption rotation issues", "Added new decoration blocks", "Performance improvements"],
        isLatest: true
      }
    ]
  },
  {
    id: "jei",
    title: "JEI (Just Enough Items)",
    author: "mezz",
    description: "The essential recipe viewing mod that provides comprehensive item information, crafting recipes, and usage data in an intuitive, searchable interface.",
    longDescription: "JEI is an item and recipe viewing mod for Minecraft, built from the ground up for stability and performance. It shows the recipes and uses of any item and has an API for integration with other mods.",
    downloads: 42150000,
    likes: 189234,
    views: 5247382,
    rating: 4.9,
    category: "Utility",
    type: "mod",
    tags: ["Forge", "Fabric", "Quilt", "Essential", "Recipe", "Utility"],
    lastUpdated: "3 days ago",
    license: "MIT",
    environment: "client",
    modLoader: ["Forge", "Fabric", "Quilt"],
    featured: true,
    versions: [
      {
        version: "15.2.0.27",
        mcVersion: "1.20.4",
        downloadUrl: "/downloads/jei-15.2.0.27-forge.jar",
        fileSize: "2.1 MB",
        releaseDate: "2024-01-12",
        changelog: ["Updated for MC 1.20.4", "Fixed recipe display issues", "Improved performance"],
        isLatest: true
      }
    ]
  },
  {
    id: "tinkers-construct",
    title: "Tinkers' Construct",
    author: "mDiyo",
    description: "Revolutionary tool crafting system allowing complete customization of tools and weapons through material combinations, modifiers, and special abilities.",
    longDescription: "Tinkers' Construct is a mod about putting tools together in a wide variety of ways, then modifying them until they turn into something else. The tools never disappear and can be named and changed to your heart's desire.",
    downloads: 28890000,
    likes: 198765,
    views: 3847291,
    rating: 4.7,
    category: "Tools",
    type: "mod",
    tags: ["Forge", "Tools", "Customization", "Crafting", "Weapons"],
    lastUpdated: "5 days ago",
    license: "MIT",
    environment: "both",
    modLoader: ["Forge"],
    featured: true,
    versions: [
      {
        version: "3.7.1.185",
        mcVersion: "1.20.1",
        downloadUrl: "/downloads/tinkers-3.7.1.185.jar",
        fileSize: "15.3 MB",
        releaseDate: "2024-01-07",
        changelog: ["New tool materials", "Fixed smeltery issues", "Added new modifiers"],
        isLatest: true
      }
    ]
  },
  // Adventure & Exploration Mods
  {
    id: "biomes-o-plenty",
    title: "Biomes O' Plenty",
    author: "Forstride",
    description: "Explore over 80 stunning new biomes, each with unique blocks, plants, and environmental features that transform world generation and exploration.",
    longDescription: "Biomes O' Plenty is an expansive biome mod for Minecraft that adds a slew of new, unique biomes to the Overworld and Nether! To go along with the new biomes, it adds new plants, flowers, trees, building blocks, and much more!",
    downloads: 23740000,
    likes: 142356,
    views: 2957384,
    rating: 4.6,
    category: "Adventure",
    type: "mod",
    tags: ["Forge", "Fabric", "Biomes", "Exploration", "World Generation"],
    lastUpdated: "1 week ago",
    license: "CC BY-NC-SA 4.0",
    environment: "both",
    modLoader: ["Forge", "Fabric"],
    featured: true,
    versions: [
      {
        version: "18.0.0.592",
        mcVersion: "1.20.1",
        downloadUrl: "/downloads/biomes-o-plenty-18.0.0.592.jar",
        fileSize: "7.8 MB",
        releaseDate: "2024-01-05",
        changelog: ["Added 5 new biomes", "Updated textures", "Fixed generation issues"],
        isLatest: true
      }
    ]
  },
  {
    id: "twilight-forest",
    title: "The Twilight Forest",
    author: "TeamTwilight",
    description: "Enter a mysterious dimension filled with magical creatures, challenging bosses, unique structures, and enchanted treasures waiting to be discovered.",
    longDescription: "The Twilight Forest is a dimension exploration mod focused on adventure that will take you on a journey to meet strange creatures, explore dungeons, and much more.",
    downloads: 16280000,
    likes: 128456,
    views: 2146738,
    rating: 4.8,
    category: "Adventure",
    type: "mod",
    tags: ["Forge", "Dimension", "Bosses", "Magic", "Adventure"],
    lastUpdated: "6 days ago",
    license: "LGPLv2.1",
    environment: "both",
    modLoader: ["Forge"],
    versions: [
      {
        version: "4.2.1518",
        mcVersion: "1.20.1",
        downloadUrl: "/downloads/twilight-forest-4.2.1518.jar",
        fileSize: "25.4 MB",
        releaseDate: "2024-01-03",
        changelog: ["New boss encounters", "Fixed dungeon generation", "Added new items"],
        isLatest: true
      }
    ]
  },
  // Utility Mods
  {
    id: "waystones",
    title: "Waystones",
    author: "BlayTheNinth",
    description: "Fast travel system using magical waystones that can be placed throughout your world, allowing instant teleportation between discovered locations.",
    longDescription: "Waystones is a fairly simple mod that adds waystone blocks that the player can return to once they've been activated, either through a Return Scroll, a Warp Stone or if enabled, a button in the inventory screen.",
    downloads: 22340000,
    likes: 156789,
    views: 2934857,
    rating: 4.7,
    category: "Utility",
    type: "mod",
    tags: ["Forge", "Fabric", "Travel", "Magic", "Teleportation"],
    lastUpdated: "3 days ago",
    license: "MIT",
    environment: "both",
    modLoader: ["Forge", "Fabric"],
    versions: [
      {
        version: "14.1.3",
        mcVersion: "1.20.4",
        downloadUrl: "/downloads/waystones-14.1.3.jar",
        fileSize: "3.2 MB",
        releaseDate: "2024-01-14",
        changelog: ["Fixed teleportation bugs", "Added new waystone variants", "Improved GUI"],
        isLatest: true
      }
    ]
  },
  {
    id: "iron-chests",
    title: "Iron Chests",
    author: "ProgWML6",
    description: "Upgrade your storage capacity with a variety of chest types made from different materials, each offering increased storage space and unique features.",
    longDescription: "Iron Chests adds new chest types to the game. There are copper, iron, silver, gold, diamond, crystal, and obsidian chests, as well as dirt chests.",
    downloads: 18950000,
    likes: 95432,
    views: 1847392,
    rating: 4.5,
    category: "Storage",
    type: "mod",
    tags: ["Forge", "Fabric", "Storage", "Chests", "Utility"],
    lastUpdated: "1 week ago",
    license: "MIT",
    environment: "both",
    modLoader: ["Forge", "Fabric"],
    versions: [
      {
        version: "14.4.1.19",
        mcVersion: "1.20.1",
        downloadUrl: "/downloads/iron-chests-14.4.1.19.jar",
        fileSize: "1.8 MB",
        releaseDate: "2024-01-01",
        changelog: ["Updated textures", "Fixed inventory sync", "Added new chest types"],
        isLatest: true
      }
    ]
  },
  // Server Plugins (Bukkit/Spigot/Paper)
  {
    id: "essentials",
    title: "EssentialsX",
    author: "EssentialsX Team",
    description: "The essential plugin for Bukkit servers, providing over 100 commands and features including economy, homes, warps, kits, and administrative tools.",
    longDescription: "EssentialsX is the essential plugin for Spigot servers, providing core features for almost every Spigot server. These features include player made homes and warps, economical features such as server shops and auctions, and administrative features.",
    downloads: 8950000,
    likes: 87654,
    views: 1547392,
    rating: 4.6,
    category: "Server Management",
    type: "plugin",
    tags: ["Bukkit", "Spigot", "Paper", "Economy", "Admin", "Essential"],
    lastUpdated: "1 day ago",
    license: "GPL-3.0",
    environment: "server",
    modLoader: ["Bukkit", "Spigot", "Paper"],
    featured: true,
    versions: [
      {
        version: "2.20.1",
        mcVersion: "1.20.4",
        downloadUrl: "/downloads/EssentialsX-2.20.1.jar",
        fileSize: "2.1 MB",
        releaseDate: "2024-01-16",
        changelog: ["Updated for MC 1.20.4", "Fixed economy issues", "Added new commands"],
        isLatest: true
      }
    ]
  },
  {
    id: "worldguard",
    title: "WorldGuard",
    author: "EngineHub",
    description: "Powerful world protection plugin that allows server administrators to protect areas, control PvP, block griefing, and manage player permissions.",
    longDescription: "WorldGuard lets you and players guard areas of land against griefers and undesirables, as well as tweak and disable various gameplay features of Minecraft.",
    downloads: 12450000,
    likes: 134567,
    views: 2147392,
    rating: 4.8,
    category: "Protection",
    type: "plugin",
    tags: ["Bukkit", "Spigot", "Paper", "Protection", "Admin", "PvP"],
    lastUpdated: "4 days ago",
    license: "LGPLv3",
    environment: "server",
    modLoader: ["Bukkit", "Spigot", "Paper"],
    featured: true,
    versions: [
      {
        version: "7.0.9",
        mcVersion: "1.20.4",
        downloadUrl: "/downloads/worldguard-bukkit-7.0.9.jar",
        fileSize: "1.9 MB",
        releaseDate: "2024-01-13",
        changelog: ["Improved region protection", "Fixed flag conflicts", "Performance optimizations"],
        isLatest: true
      }
    ]
  },
  // More mods and plugins...
  {
    id: "thermal-expansion",
    title: "Thermal Expansion",
    author: "TeamCoFH",
    description: "Industrial-grade machines and energy systems for large-scale automation, resource processing, and power generation with modular upgrades.",
    longDescription: "Thermal Expansion is a tech mod created by Team CoFH. It expands the usage of Redstone Flux (RF) in the world, adding machines that allow for processing resources, and ways to simplify transportation of items, energy and liquids to distant bases.",
    downloads: 19740000,
    likes: 134782,
    views: 2485739,
    rating: 4.7,
    category: "Technology",
    type: "mod",
    tags: ["Forge", "Energy", "Machines", "Industrial", "Automation"],
    lastUpdated: "4 days ago",
    license: "Custom",
    environment: "both",
    modLoader: ["Forge"],
    versions: [
      {
        version: "10.4.2.18",
        mcVersion: "1.20.1",
        downloadUrl: "/downloads/thermal-expansion-10.4.2.18.jar",
        fileSize: "6.7 MB",
        releaseDate: "2024-01-09",
        changelog: ["New energy storage options", "Machine efficiency improvements", "Bug fixes"],
        isLatest: true
      }
    ]
  },
  {
    id: "optifine",
    title: "OptiFine",
    author: "sp614x",
    description: "Essential optimization mod that dramatically improves graphics performance, adds advanced visual settings, and supports HD textures and shaders.",
    longDescription: "OptiFine is a Minecraft optimization mod. It allows Minecraft to run faster and look better with full support for HD textures and many configuration options.",
    downloads: 89450000,
    likes: 567890,
    views: 12547392,
    rating: 4.9,
    category: "Performance",
    type: "mod",
    tags: ["Performance", "Graphics", "Shaders", "HD Textures", "FPS"],
    lastUpdated: "2 days ago",
    license: "Custom",
    environment: "client",
    modLoader: ["Forge", "Fabric"],
    featured: true,
    trending: true,
    versions: [
      {
        version: "HD_U_I6",
        mcVersion: "1.20.4",
        downloadUrl: "/downloads/OptiFine_1.20.4_HD_U_I6.jar",
        fileSize: "3.1 MB",
        releaseDate: "2024-01-15",
        changelog: ["Updated for MC 1.20.4", "Improved shader support", "Performance optimizations"],
        isLatest: true
      },
      {
        version: "HD_U_I5",
        mcVersion: "1.20.2",
        downloadUrl: "/downloads/OptiFine_1.20.2_HD_U_I5.jar",
        fileSize: "3.0 MB",
        releaseDate: "2024-01-01",
        changelog: ["Fixed rendering issues", "Updated shader packs support"]
      }
    ]
  },
  {
    id: "sodium",
    title: "Sodium",
    author: "JellySquid",
    description: "Modern rendering engine replacement that dramatically improves frame rates, reduces stuttering, and fixes graphical issues in Minecraft.",
    longDescription: "Sodium is a free and open-source rendering engine replacement for the Minecraft client that greatly improves frame rates, reduces micro-stutter, and fixes graphical issues in Minecraft.",
    downloads: 45670000,
    likes: 345678,
    views: 8547392,
    rating: 4.8,
    category: "Performance",
    type: "mod",
    tags: ["Fabric", "Performance", "Rendering", "FPS", "Optimization"],
    lastUpdated: "1 week ago",
    license: "LGPLv3",
    environment: "client",
    modLoader: ["Fabric"],
    featured: true,
    versions: [
      {
        version: "0.5.8",
        mcVersion: "1.20.4",
        downloadUrl: "/downloads/sodium-fabric-0.5.8.jar",
        fileSize: "876 KB",
        releaseDate: "2024-01-12",
        changelog: ["Major performance improvements", "Fixed memory leaks", "Better compatibility"],
        isLatest: true
      }
    ]
  },
  {
    id: "worldedit",
    title: "WorldEdit",
    author: "EngineHub",
    description: "In-game world editor for both single-player and multiplayer servers, allowing massive terrain modification and building projects with simple commands.",
    longDescription: "WorldEdit is an in-game map editor for Minecraft. Through a combination of commands and brush tools, you can sculpt your world or simply perform numerous terraforming tasks.",
    downloads: 15670000,
    likes: 234567,
    views: 3547392,
    rating: 4.9,
    category: "Building",
    type: "plugin",
    tags: ["Bukkit", "Spigot", "Paper", "Building", "Editor", "Terrain"],
    lastUpdated: "3 days ago",
    license: "LGPLv3",
    environment: "server",
    modLoader: ["Bukkit", "Spigot", "Paper"],
    featured: true,
    versions: [
      {
        version: "7.2.15",
        mcVersion: "1.20.4",
        downloadUrl: "/downloads/worldedit-bukkit-7.2.15.jar",
        fileSize: "4.2 MB",
        releaseDate: "2024-01-14",
        changelog: ["New brush types", "Improved selection tools", "Bug fixes"],
        isLatest: true
      }
    ]
  }
];

export const categories = [
  { id: 'technology', name: 'Technology & Automation', icon: 'ri-cpu-line' },
  { id: 'adventure', name: 'Adventure & Exploration', icon: 'ri-compass-3-line' },
  { id: 'magic', name: 'Magic & Mysticism', icon: 'ri-magic-line' },
  { id: 'building', name: 'Building & Decoration', icon: 'ri-building-4-line' },
  { id: 'utility', name: 'Tools & Utilities', icon: 'ri-tools-line' },
  { id: 'combat', name: 'Combat & Weapons', icon: 'ri-sword-line' },
  { id: 'performance', name: 'Performance & Graphics', icon: 'ri-speed-line' },
  { id: 'storage', name: 'Storage & Management', icon: 'ri-archive-line' },
  { id: 'protection', name: 'Protection & Security', icon: 'ri-shield-line' },
  { id: 'server-management', name: 'Server Management', icon: 'ri-server-line' }
];

export const mcVersions = [
  '1.20.4', '1.20.2', '1.20.1', '1.19.4', '1.19.2', '1.19.0',
  '1.18.2', '1.18.1', '1.18.0', '1.17.1', '1.16.5', '1.16.4',
  '1.15.2', '1.14.4', '1.12.2', '1.11.2', '1.10.2', '1.8.9', '1.7.10'
];

export const modLoaders = [
  { id: 'forge', name: 'Forge', icon: 'ri-hammer-line' },
  { id: 'fabric', name: 'Fabric', icon: 'ri-t-shirt-line' },
  { id: 'neoforge', name: 'NeoForge', icon: 'ri-fire-line' },
  { id: 'quilt', name: 'Quilt', icon: 'ri-palette-line' },
  { id: 'bukkit', name: 'Bukkit', icon: 'ri-server-line' },
  { id: 'spigot', name: 'Spigot', icon: 'ri-server-fill' },
  { id: 'paper', name: 'Paper', icon: 'ri-file-paper-line' }
];

// Search and filter functions
export function searchMods(query: string, filters?: any): Mod[] {
  let results = modDatabase;

  if (query) {
    results = results.filter(mod =>
      mod.title.toLowerCase().includes(query.toLowerCase()) ||
      mod.author.toLowerCase().includes(query.toLowerCase()) ||
      mod.description.toLowerCase().includes(query.toLowerCase()) ||
      mod.tags.some(tag => tag.toLowerCase().includes(query.toLowerCase()))
    );
  }

  if (filters) {
    if (filters.category && filters.category.length > 0) {
      results = results.filter(mod => filters.category.includes(mod.category.toLowerCase()));
    }
    if (filters.type && filters.type.length > 0) {
      results = results.filter(mod => filters.type.includes(mod.type));
    }
    if (filters.mcVersion && filters.mcVersion.length > 0) {
      results = results.filter(mod => 
        mod.versions.some(version => filters.mcVersion.includes(version.mcVersion))
      );
    }
    if (filters.modLoader && filters.modLoader.length > 0) {
      results = results.filter(mod => 
        mod.modLoader.some(loader => filters.modLoader.includes(loader.toLowerCase()))
      );
    }
  }

  return results;
}

export function getModById(id: string): Mod | undefined {
  return modDatabase.find(mod => mod.id === id);
}

export function getFeaturedMods(): Mod[] {
  return modDatabase.filter(mod => mod.featured);
}

export function getTrendingMods(): Mod[] {
  return modDatabase.filter(mod => mod.trending);
}