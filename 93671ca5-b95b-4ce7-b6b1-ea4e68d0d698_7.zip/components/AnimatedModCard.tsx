
'use client';

import Link from 'next/link';
import { useState } from 'react';

interface AnimatedModCardProps {
  id: string;
  title: string;
  author: string;
  description: string;
  downloads: number;
  likes: number;
  views: number;
  rating: number;
  version: string;
  category: string;
  tags: string[];
  imageUrl?: string;
  lastUpdated: string;
}

export default function AnimatedModCard({ 
  id, 
  title, 
  author, 
  description, 
  downloads, 
  likes,
  views,
  rating, 
  version, 
  category,
  tags,
  imageUrl,
  lastUpdated
}: AnimatedModCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isLiked, setIsLiked] = useState(false);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const handleLike = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsLiked(!isLiked);
  };

  return (
    <div
      className={`bg-gray-800 rounded-2xl border border-gray-700 hover:border-green-500 transition-all duration-500 cursor-pointer group overflow-hidden ${
        isExpanded ? 'scale-105 shadow-2xl z-10' : 'hover:scale-102 shadow-lg'
      }`}
      onMouseEnter={() => setIsExpanded(true)}
      onMouseLeave={() => setIsExpanded(false)}
    >
      <Link href={`/mods/${id}`}>
        <div className="relative">
          <div className="relative h-48 overflow-hidden">
            <img
              src={imageUrl || `https://readdy.ai/api/search-image?query=minecraft%20mod%20$%7Bcategory%7D%20screenshot%20game%20interface%20colorful%20blocks%20detailed%20environment%20dark%20background%20professional&width=500&height=300&seq=${id}&orientation=landscape`}
              alt={title}
              className={`w-full h-full object-cover object-top transition-all duration-700 ${
                isExpanded ? 'scale-110 brightness-110' : 'scale-100'
              }`}
            />
            <div className={`absolute inset-0 bg-gradient-to-t from-gray-900/80 via-transparent to-transparent transition-opacity duration-500 ${
              isExpanded ? 'opacity-90' : 'opacity-60'
            }`} />
            
            {/* Category Badge */}
            <div className="absolute top-3 left-3">
              <span className="bg-gray-900/90 text-gray-300 px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm">
                {category}
              </span>
            </div>

            {/* Like Button */}
            <button
              onClick={handleLike}
              className="absolute top-3 right-3 w-10 h-10 bg-gray-900/70 hover:bg-gray-900/90 rounded-full flex items-center justify-center backdrop-blur-sm transition-all duration-200 hover:scale-110"
            >
              <i className={`${isLiked ? 'ri-heart-fill text-red-500' : 'ri-heart-line text-gray-300'} text-lg`}></i>
            </button>

            {/* Rating */}
            <div className="absolute bottom-3 left-3 flex items-center space-x-1">
              <div className="flex items-center">
                {[1, 2, 3, 4, 5].map((star) => (
                  <i
                    key={star}
                    className={`ri-star-${star <= rating ? 'fill' : 'line'} text-yellow-400 text-sm`}
                  />
                ))}
              </div>
              <span className="text-white text-sm font-medium ml-1">{rating.toFixed(1)}</span>
            </div>
          </div>
          
          <div className="p-5">
            <div className="flex items-start justify-between mb-3">
              <h3 className={`text-white font-semibold text-lg leading-tight transition-all duration-300 ${
                isExpanded ? 'text-green-400' : 'group-hover:text-green-400'
              }`}>
                {title}
              </h3>
              <span className="text-green-400 text-sm font-medium ml-2 flex-shrink-0">
                v{version}
              </span>
            </div>

            <p className={`text-gray-400 text-sm mb-4 leading-relaxed transition-all duration-500 ${
              isExpanded ? 'line-clamp-3' : 'line-clamp-2'
            }`}>
              {description}
            </p>

            <div className="flex items-center justify-between mb-4">
              <span className="text-gray-300 text-sm">by {author}</span>
              <span className="text-gray-500 text-xs">{lastUpdated}</span>
            </div>

            {/* Tags */}
            <div className={`mb-4 overflow-hidden transition-all duration-500 ${
              isExpanded ? 'max-h-20 opacity-100' : 'max-h-0 opacity-0'
            }`}>
              <div className="flex flex-wrap gap-1">
                {tags.slice(0, 4).map((tag) => (
                  <span
                    key={tag}
                    className="bg-gray-700 text-gray-300 px-2 py-1 rounded-full text-xs"
                  >
                    {tag}
                  </span>
                ))}
                {tags.length > 4 && (
                  <span className="text-gray-500 text-xs py-1">+{tags.length - 4}</span>
                )}
              </div>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div className="text-center">
                <div className="flex items-center justify-center space-x-1">
                  <i className="ri-download-line text-gray-400 text-base"></i>
                  <span className="text-gray-400 text-xs">Downloads</span>
                </div>
                <span className="text-white font-semibold block mt-1">{formatNumber(downloads)}</span>
              </div>
              
              <div className="text-center">
                <div className="flex items-center justify-center space-x-1">
                  <i className="ri-heart-line text-gray-400 text-base"></i>
                  <span className="text-gray-400 text-xs">Likes</span>
                </div>
                <span className="text-white font-semibold block mt-1">{formatNumber(likes)}</span>
              </div>
              
              <div className="text-center">
                <div className="flex items-center justify-center space-x-1">
                  <i className="ri-eye-line text-gray-400 text-base"></i>
                  <span className="text-gray-400 text-xs">Views</span>
                </div>
                <span className="text-white font-semibold block mt-1">{formatNumber(views)}</span>
              </div>
            </div>

            {/* Download Button - Only visible on hover/expand */}
            <div className={`mt-4 transition-all duration-500 ${
              isExpanded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
            }`}>
              <Link href={`/mods/${id}`}>
                <button 
                  className="w-full bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white py-3 rounded-lg font-medium transition-all duration-200 whitespace-nowrap cursor-pointer shadow-lg hover:shadow-xl"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    window.location.href = `/mods/${id}`;
                  }}
                >
                  <i className="ri-download-line mr-2"></i>
                  Download Now
                </button>
              </Link>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}
