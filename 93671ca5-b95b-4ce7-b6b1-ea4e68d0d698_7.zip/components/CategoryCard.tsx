'use client';

interface CategoryCardProps {
  title: string;
  icon: string;
  count: number;
  description: string;
  onClick?: () => void;
}

export default function CategoryCard({ title, icon, count, description, onClick }: CategoryCardProps) {
  return (
    <div 
      onClick={onClick}
      className="bg-gray-800 rounded-xl p-6 border border-gray-700 hover:border-green-500 transition-all duration-300 cursor-pointer group"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center group-hover:bg-green-500 transition-colors">
          <i className={`${icon} text-white text-xl`}></i>
        </div>
        <span className="text-gray-400 text-sm font-medium">{count} mods</span>
      </div>
      <h3 className="text-white font-semibold text-lg mb-2">{title}</h3>
      <p className="text-gray-400 text-sm">{description}</p>
    </div>
  );
}