
'use client';

import { useState } from 'react';

interface FilterOption {
  id: string;
  label: string;
  count?: number;
}

interface FilterSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onFiltersChange?: (filters: any) => void;
}

export default function FilterSidebar({ isOpen, onClose, onFiltersChange }: FilterSidebarProps) {
  const [selectedVersion, setSelectedVersion] = useState<string[]>([]);
  const [selectedType, setSelectedType] = useState<string[]>([]);
  const [selectedLicense, setSelectedLicense] = useState<string[]>([]);
  const [selectedEnvironment, setSelectedEnvironment] = useState<string[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  const versions: FilterOption[] = [
    { id: '1.20.4', label: '1.20.4', count: 2847 },
    { id: '1.20.2', label: '1.20.2', count: 3124 },
    { id: '1.19.4', label: '1.19.4', count: 4567 },
    { id: '1.19.2', label: '1.19.2', count: 5891 },
    { id: '1.18.2', label: '1.18.2', count: 3456 },
    { id: '1.16.5', label: '1.16.5', count: 7892 }
  ];

  const modTypes: FilterOption[] = [
    { id: 'mod', label: 'Mod', count: 45678 },
    { id: 'modpack', label: 'Modpack', count: 1234 },
    { id: 'resourcepack', label: 'Resource Pack', count: 2345 },
    { id: 'shader', label: 'Shader', count: 876 }
  ];

  const licenses: FilterOption[] = [
    { id: 'mit', label: 'MIT', count: 12456 },
    { id: 'gpl', label: 'GPL-3.0', count: 8934 },
    { id: 'apache', label: 'Apache-2.0', count: 5678 },
    { id: 'cc0', label: 'CC0-1.0', count: 3421 },
    { id: 'custom', label: 'Custom', count: 9876 }
  ];

  const environments: FilterOption[] = [
    { id: 'client', label: 'Client-side', count: 23456 },
    { id: 'server', label: 'Server-side', count: 18734 },
    { id: 'both', label: 'Client & Server', count: 34567 }
  ];

  const tags: FilterOption[] = [
    { id: 'forge', label: 'Forge', count: 28934 },
    { id: 'fabric', label: 'Fabric', count: 19876 },
    { id: 'neoforge', label: 'NeoForge', count: 8456 },
    { id: 'quilt', label: 'Quilt', count: 4532 },
    { id: 'technology', label: 'Technology', count: 12456 },
    { id: 'magic', label: 'Magic', count: 8934 },
    { id: 'adventure', label: 'Adventure', count: 15678 },
    { id: 'building', label: 'Building', count: 9876 }
  ];

  const handleCheckboxChange = (value: string, currentSelection: string[], setter: React.Dispatch<React.SetStateAction<string[]>>) => {
    const updated = currentSelection.includes(value)
      ? currentSelection.filter(item => item !== value)
      : [...currentSelection, value];
    setter(updated);
  };

  const clearAllFilters = () => {
    setSelectedVersion([]);
    setSelectedType([]);
    setSelectedLicense([]);
    setSelectedEnvironment([]);
    setSelectedTags([]);
  };

  const FilterSection = ({ title, options, selected, onChange }: {
    title: string;
    options: FilterOption[];
    selected: string[];
    onChange: (value: string) => void;
  }) => {
    const [isExpanded, setIsExpanded] = useState(true);

    return (
      <div className="mb-6">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center justify-between w-full text-white font-semibold mb-3 cursor-pointer hover:text-green-400 transition-colors"
        >
          {title}
          <i className={`ri-arrow-${isExpanded ? 'up' : 'down'}-s-line`}></i>
        </button>
        
        {isExpanded && (
          <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar">
            {options.map((option) => (
              <label key={option.id} className="flex items-center space-x-3 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={selected.includes(option.id)}
                  onChange={() => onChange(option.id)}
                  className="w-4 h-4 text-green-600 bg-gray-800 border-gray-600 rounded focus:ring-green-500 focus:ring-2"
                />
                <span className="text-gray-300 group-hover:text-white transition-colors flex-1">
                  {option.label}
                </span>
                {option.count && (
                  <span className="text-gray-500 text-sm">
                    {option.count.toLocaleString()}
                  </span>
                )}
              </label>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      <div className={`
        fixed lg:sticky top-0 left-0 h-screen lg:h-auto w-80 bg-gray-800 border-r border-gray-700 z-50
        transform transition-transform duration-300 lg:translate-x-0
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 h-full overflow-y-auto">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-white">Filters</h3>
            <div className="flex items-center space-x-2">
              <button
                onClick={clearAllFilters}
                className="text-gray-400 hover:text-white text-sm cursor-pointer transition-colors"
              >
                Clear All
              </button>
              <button
                onClick={onClose}
                className="lg:hidden w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white cursor-pointer"
              >
                <i className="ri-close-line"></i>
              </button>
            </div>
          </div>

          <FilterSection
            title="Game Version"
            options={versions}
            selected={selectedVersion}
            onChange={(value) => handleCheckboxChange(value, selectedVersion, setSelectedVersion)}
          />

          <FilterSection
            title="Mod Type"
            options={modTypes}
            selected={selectedType}
            onChange={(value) => handleCheckboxChange(value, selectedType, setSelectedType)}
          />

          <FilterSection
            title="License"
            options={licenses}
            selected={selectedLicense}
            onChange={(value) => handleCheckboxChange(value, selectedLicense, setSelectedLicense)}
          />

          <FilterSection
            title="Environment"
            options={environments}
            selected={selectedEnvironment}
            onChange={(value) => handleCheckboxChange(value, selectedEnvironment, setSelectedEnvironment)}
          />

          <FilterSection
            title="Tags"
            options={tags}
            selected={selectedTags}
            onChange={(value) => handleCheckboxChange(value, selectedTags, setSelectedTags)}
          />

          <div className="mt-8 pt-6 border-t border-gray-700">
            <button className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-medium transition-colors duration-200 whitespace-nowrap cursor-pointer">
              Apply Filters
            </button>
          </div>
        </div>

        <style jsx>{`
          .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: #374151;
            border-radius: 2px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #6b7280;
            border-radius: 2px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #9ca3af;
          }
        `}</style>
      </div>
    </>
  );
}
