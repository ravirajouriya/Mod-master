
'use client';

import { useState, useRef, useEffect } from 'react';
import { searchMods, modDatabase } from '@/lib/modDatabase';

interface SearchSuggestion {
  id: string;
  title: string;
  type: 'mod' | 'plugin' | 'author' | 'category';
  icon: string;
}

interface EnhancedSearchBarProps {
  onSearch?: (query: string) => void;
  placeholder?: string;
  showSuggestions?: boolean;
}

export default function EnhancedSearchBar({ 
  onSearch, 
  placeholder = "Search for mods, plugins, modpacks, authors...",
  showSuggestions = true 
}: EnhancedSearchBarProps) {
  const [query, setQuery] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  const generateSuggestions = (searchQuery: string): SearchSuggestion[] => {
    if (searchQuery.length < 2) return [];

    const results: SearchSuggestion[] = [];
    const query = searchQuery.toLowerCase();

    const modResults = modDatabase
      .filter(mod => 
        mod.title.toLowerCase().includes(query) ||
        mod.description.toLowerCase().includes(query) ||
        mod.tags.some(tag => tag.toLowerCase().includes(query))
      )
      .slice(0, 4)
      .map(mod => ({
        id: mod.id,
        title: mod.title,
        type: mod.type as 'mod' | 'plugin',
        icon: mod.type === 'plugin' ? 'ri-server-line' : 'ri-puzzle-line'
      }));

    results.push(...modResults);

    const authorResults = Array.from(new Set(
      modDatabase
        .filter(mod => mod.author.toLowerCase().includes(query))
        .map(mod => mod.author)
    ))
      .slice(0, 2)
      .map(author => ({
        id: `author-${author}`,
        title: author,
        type: 'author' as const,
        icon: 'ri-user-line'
      }));

    results.push(...authorResults);

    const categories = ['Technology', 'Adventure', 'Utility', 'Tools', 'Building', 'Performance'];
    const categoryResults = categories
      .filter(cat => cat.toLowerCase().includes(query))
      .slice(0, 2)
      .map(category => ({
        id: `category-${category}`,
        title: category,
        type: 'category' as const,
        icon: 'ri-folder-line'
      }));

    results.push(...categoryResults);

    return results.slice(0, 8);
  };

  useEffect(() => {
    const suggestions = generateSuggestions(query);
    setSuggestions(suggestions);
    setShowDropdown(suggestions.length > 0 && isActive);
  }, [query, isActive]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
        setIsActive(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      if (onSearch) {
        onSearch(query);
      } else {
        window.location.href = `/mods?search=${encodeURIComponent(query)}`;
      }
    }
    setShowDropdown(false);
    setIsActive(false);
  };

  const handleSuggestionClick = (suggestion: SearchSuggestion) => {
    if (suggestion.type === 'mod' || suggestion.type === 'plugin') {
      window.location.href = `/mods/${suggestion.id}`;
    } else if (suggestion.type === 'author') {
      window.location.href = `/mods?author=${encodeURIComponent(suggestion.title)}`;
    } else if (suggestion.type === 'category') {
      window.location.href = `/mods?category=${encodeURIComponent(suggestion.title.toLowerCase())}`;
    } else {
      setQuery(suggestion.title);
      if (onSearch) {
        onSearch(suggestion.title);
      } else {
        window.location.href = `/mods?search=${encodeURIComponent(suggestion.title)}`;
      }
    }
    setShowDropdown(false);
    setIsActive(false);
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'mod': return 'text-green-400';
      case 'plugin': return 'text-orange-400';
      case 'author': return 'text-blue-400';
      case 'category': return 'text-purple-400';
      default: return 'text-gray-400';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'mod': return 'Mod';
      case 'plugin': return 'Plugin';
      case 'author': return 'Author';
      case 'category': return 'Category';
      default: return type;
    }
  };

  return (
    <div ref={searchRef} className="relative w-full max-w-4xl mx-auto">
      <form onSubmit={handleSearch} className="relative">
        <div className={`relative transition-all duration-300 ${isActive ? 'scale-105' : 'scale-100'}`}>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsActive(true)}
            placeholder={placeholder}
            className="w-full bg-gray-800/90 backdrop-blur-sm border border-gray-700 rounded-2xl pl-14 pr-20 py-5 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 text-lg transition-all duration-300 shadow-2xl"
          />
          <div className="absolute left-5 top-1/2 transform -translate-y-1/2">
            <div className="w-6 h-6 flex items-center justify-center">
              <i className={`ri-search-line text-gray-400 text-xl transition-all duration-300 ${isActive ? 'text-green-400 scale-110' : ''}`}></i>
            </div>
          </div>
          <button
            type="submit"
            className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white px-6 py-3 rounded-xl font-medium text-sm whitespace-nowrap cursor-pointer transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
          >
            Search
          </button>
        </div>
      </form>

      {showSuggestions && showDropdown && suggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-gray-800 border border-gray-700 rounded-xl shadow-2xl backdrop-blur-sm z-50 overflow-hidden animate-in slide-in-from-top-2 duration-200">
          <div className="max-h-80 overflow-y-auto">
            {suggestions.map((suggestion, index) => (
              <div
                key={suggestion.id}
                onClick={() => handleSuggestionClick(suggestion)}
                className="flex items-center space-x-3 px-4 py-3 hover:bg-gray-700 cursor-pointer transition-colors duration-200 border-b border-gray-700 last:border-b-0"
              >
                <div className="w-8 h-8 flex items-center justify-center">
                  <i className={`${suggestion.icon} ${getTypeColor(suggestion.type)} text-lg`}></i>
                </div>
                <div className="flex-1">
                  <span className="text-white font-medium">{suggestion.title}</span>
                  <span className={`ml-2 text-xs px-2 py-1 rounded-full ${getTypeColor(suggestion.type)} bg-gray-900/50`}>
                    {getTypeLabel(suggestion.type)}
                  </span>
                </div>
                {(suggestion.type === 'mod' || suggestion.type === 'plugin') && (
                  <div className="text-gray-400 text-xs">
                    <i className="ri-arrow-right-line"></i>
                  </div>
                )}
              </div>
            ))}
          </div>
          
          {query.length >= 2 && (
            <div className="border-t border-gray-700 p-3">
              <button
                onClick={handleSearch}
                className="w-full text-left text-green-400 hover:text-green-300 font-medium flex items-center space-x-2 cursor-pointer"
              >
                <i className="ri-search-line"></i>
                <span>Search for "{query}"</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
