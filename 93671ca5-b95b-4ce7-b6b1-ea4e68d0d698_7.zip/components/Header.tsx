'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-gray-900 border-b border-gray-800 sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
                <i className="ri-apps-2-fill text-white text-lg"></i>
              </div>
              <span className="font-['Pacifico'] text-xl text-white">ModCraft</span>
            </Link>
          </div>

          <div className="hidden md:block">
            <div className="flex items-center space-x-8">
              <Link href="/" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium whitespace-nowrap cursor-pointer transition-colors">
                Home
              </Link>
              <Link href="/mods" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium whitespace-nowrap cursor-pointer transition-colors">
                Mods
              </Link>
              <Link href="/submit" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium whitespace-nowrap cursor-pointer transition-colors">
                Submit Mod
              </Link>
              <Link href="/about" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium whitespace-nowrap cursor-pointer transition-colors">
                About
              </Link>
              <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap cursor-pointer transition-colors">
                Sign In
              </button>
            </div>
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-400 hover:text-white p-2 cursor-pointer"
            >
              <i className="ri-menu-line text-xl"></i>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-800">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <Link href="/" className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium cursor-pointer">
                Home
              </Link>
              <Link href="/mods" className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium cursor-pointer">
                Mods
              </Link>
              <Link href="/submit" className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium cursor-pointer">
                Submit Mod
              </Link>
              <Link href="/about" className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium cursor-pointer">
                About
              </Link>
              <button className="w-full text-left bg-green-600 hover:bg-green-700 text-white block px-3 py-2 text-base font-medium rounded-lg mt-2 cursor-pointer">
                Sign In
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}