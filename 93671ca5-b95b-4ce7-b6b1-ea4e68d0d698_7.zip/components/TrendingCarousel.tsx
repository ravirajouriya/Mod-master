
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface TrendingMod {
  id: string;
  title: string;
  author: string;
  downloads: string;
  image: string;
  description: string;
  trending: boolean;
}

export default function TrendingCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const trendingMods: TrendingMod[] = [
    {
      id: '1',
      title: 'Applied Energistics 2',
      author: 'AlgorithmX2',
      downloads: '25.4M',
      description: 'Revolutionary storage and automation system',
      image: 'minecraft mod applied energistics 2 digital storage system futuristic technology blue glowing screens dark background detailed 3d render',
      trending: true
    },
    {
      id: '2',
      title: 'Create',
      author: 'simibubi',
      downloads: '31.2M',
      description: 'Building contraptions and mechanical engineering',
      image: 'minecraft mod create mechanical contraptions gears steam engines industrial factory complex machinery bronze copper colors',
      trending: true
    },
    {
      id: '3',
      title: 'Tinkers Construct',
      author: 'mDiyo',
      downloads: '28.9M',
      description: 'Customize and craft unique tools and weapons',
      image: 'minecraft mod tinkers construct tool forge smeltery molten metal casting crafting station orange glow fantasy workshop',
      trending: true
    },
    {
      id: '4',
      title: 'Thermal Expansion',
      author: 'TeamCoFH',
      downloads: '19.7M',
      description: 'Advanced machines and energy systems',
      image: 'minecraft mod thermal expansion machines energy conduits redstone flux technology industrial complex orange red colors',
      trending: true
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % trendingMods.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [trendingMods.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % trendingMods.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + trendingMods.length) % trendingMods.length);
  };

  return (
    <div className="relative w-full max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Trending Now</h2>
          <p className="text-gray-400">The hottest mods this week</p>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={prevSlide}
            className="w-10 h-10 bg-gray-800 hover:bg-gray-700 border border-gray-600 rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 hover:scale-105"
          >
            <i className="ri-arrow-left-line text-white"></i>
          </button>
          <button
            onClick={nextSlide}
            className="w-10 h-10 bg-gray-800 hover:bg-gray-700 border border-gray-600 rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 hover:scale-105"
          >
            <i className="ri-arrow-right-line text-white"></i>
          </button>
        </div>
      </div>

      <div className="relative overflow-hidden rounded-2xl">
        <div 
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentSlide * 100}%)` }}
        >
          {trendingMods.map((mod, index) => (
            <div key={mod.id} className="w-full flex-shrink-0">
              <Link href={`/mods/${mod.id}`}>
                <div className="relative h-80 bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl overflow-hidden group cursor-pointer">
                  <div 
                    className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                    style={{
                      backgroundImage: `url('https://readdy.ai/api/search-image?query=$%7Bmod.image%7D&width=1200&height=600&seq=${mod.id}-trending&orientation=landscape')`
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-gray-900/90 via-gray-900/50 to-transparent"></div>
                  
                  <div className="absolute inset-0 flex items-center">
                    <div className="max-w-2xl px-12">
                      <div className="flex items-center space-x-2 mb-4">
                        <span className="bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full animate-pulse">
                          🔥 TRENDING
                        </span>
                        <span className="text-gray-300 text-sm">by {mod.author}</span>
                      </div>
                      
                      <h3 className="text-4xl font-bold text-white mb-4 group-hover:text-green-400 transition-colors duration-300">
                        {mod.title}
                      </h3>
                      
                      <p className="text-gray-300 text-lg mb-6 max-w-lg">
                        {mod.description}
                      </p>
                      
                      <div className="flex items-center space-x-6">
                        <div className="flex items-center space-x-2">
                          <i className="ri-download-line text-green-400"></i>
                          <span className="text-white font-semibold">{mod.downloads} downloads</span>
                        </div>
                        <div className="bg-green-600 hover:bg-green-500 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 whitespace-nowrap">
                          View Mod
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>

        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {trendingMods.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-2 h-2 rounded-full transition-all duration-300 cursor-pointer ${
                index === currentSlide ? 'bg-green-400 w-8' : 'bg-gray-600'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
