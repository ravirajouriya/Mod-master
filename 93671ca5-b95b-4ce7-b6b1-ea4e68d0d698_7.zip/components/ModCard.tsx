'use client';

import Link from 'next/link';

interface ModCardProps {
  id: string;
  title: string;
  author: string;
  description: string;
  downloads: number;
  rating: number;
  version: string;
  category: string;
  imageUrl?: string;
}

export default function ModCard({ 
  id, 
  title, 
  author, 
  description, 
  downloads, 
  rating, 
  version, 
  category,
  imageUrl 
}: ModCardProps) {
  const formatDownloads = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <Link href={`/mods/${id}`}>
      <div className="bg-gray-800 rounded-xl border border-gray-700 hover:border-green-500 transition-all duration-300 cursor-pointer group overflow-hidden">
        <div className="relative h-48">
          <img
            src={imageUrl || `https://readdy.ai/api/search-image?query=minecraft%20mod%20$%7Bcategory%7D%20screenshot%20game%20interface%20colorful%20blocks%20pixelated%20style%20simple%20background%20dark%20theme&width=400&height=300&seq=${id}&orientation=landscape`}
            alt={title}
            className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute top-3 right-3">
            <span className="bg-gray-900/80 text-gray-300 px-2 py-1 rounded-full text-xs font-medium">
              {category}
            </span>
          </div>
        </div>
        
        <div className="p-5">
          <h3 className="text-white font-semibold text-lg mb-2 group-hover:text-green-400 transition-colors">
            {title}
          </h3>
          <p className="text-gray-400 text-sm mb-3 line-clamp-2">
            {description}
          </p>
          
          <div className="flex items-center justify-between mb-3">
            <span className="text-gray-300 text-sm">by {author}</span>
            <span className="text-green-400 text-sm font-medium">v{version}</span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-download-line text-gray-400"></i>
                </div>
                <span className="text-gray-400">{formatDownloads(downloads)}</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-4 h-4 flex items-center justify-center">
                  <i className="ri-star-fill text-yellow-400"></i>
                </div>
                <span className="text-gray-400">{rating.toFixed(1)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}