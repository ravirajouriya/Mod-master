'use client';

export default function Footer() {
  return (
    <footer className="bg-gray-900 border-t border-gray-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
                <i className="ri-apps-2-fill text-white text-lg"></i>
              </div>
              <span className="font-['Pacifico'] text-xl text-white">ModCraft</span>
            </div>
            <p className="text-gray-400 text-sm max-w-md mb-6">
              The ultimate destination for Minecraft mods and modpacks. Discover, download, and share amazing modifications for your Minecraft experience.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white cursor-pointer transition-colors">
                <div className="w-8 h-8 flex items-center justify-center">
                  <i className="ri-twitter-fill text-lg"></i>
                </div>
              </a>
              <a href="#" className="text-gray-400 hover:text-white cursor-pointer transition-colors">
                <div className="w-8 h-8 flex items-center justify-center">
                  <i className="ri-discord-fill text-lg"></i>
                </div>
              </a>
              <a href="#" className="text-gray-400 hover:text-white cursor-pointer transition-colors">
                <div className="w-8 h-8 flex items-center justify-center">
                  <i className="ri-github-fill text-lg"></i>
                </div>
              </a>
              <a href="#" className="text-gray-400 hover:text-white cursor-pointer transition-colors">
                <div className="w-8 h-8 flex items-center justify-center">
                  <i className="ri-youtube-fill text-lg"></i>
                </div>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Community</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white text-sm cursor-pointer transition-colors">Discord Server</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white text-sm cursor-pointer transition-colors">Reddit</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white text-sm cursor-pointer transition-colors">Forums</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white text-sm cursor-pointer transition-colors">Support</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white text-sm cursor-pointer transition-colors">API Documentation</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white text-sm cursor-pointer transition-colors">Mod Guidelines</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white text-sm cursor-pointer transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white text-sm cursor-pointer transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2024 ModCraft. All rights reserved.
          </p>
          <p className="text-gray-400 text-sm mt-4 md:mt-0">
            Made with <i className="ri-heart-fill text-red-500"></i> for the Minecraft community
          </p>
        </div>
      </div>
    </footer>
  );
}